fprintf('  --> Initializing 2DG ...')
d0=fileparts([pwd,filesep]);
addpath([d0,'/distmesh']);
addpath([d0,'/mesh']);
addpath([d0,'/util']);
addpath([d0,'/master']);
addpath([d0,'/app']);
fprintf(' Done.\n\n');
clear d0
