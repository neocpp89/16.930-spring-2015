classdef testGaussQuadrature < matlab.unittest.TestCase
    % Tests gauss quadrature integration
    
    methods (Test)
        
        %----------
        function testMonomialsP0(testCase)
            f = @(x) 1;
            actSolution = GaussQuadrature(f,0);
            expSolution = 2;
            testCase.verifyEqual(actSolution,expSolution,'Abstol',1e-10);
        end
        
        %----------
        function testMonomialsP1(testCase)
            f = @(x) 1 + x;
            actSolution = GaussQuadrature(f,1);
            expSolution = 2;
            testCase.verifyEqual(actSolution,expSolution,'Abstol',1e-10);
        end
        
        %----------
        function testMonomialsP2(testCase)
            f = @(x) 1 + x + x.^2;
            actSolution = GaussQuadrature(f,2);
            expSolution = 8/3;
            testCase.verifyEqual(actSolution,expSolution,'Abstol',1e-10);
        end
        
        %----------
        function testMonomialsP3(testCase)
            f = @(x) 1 + x + x.^2 + x.^3;
            actSolution = GaussQuadrature(f,3);
            expSolution = 8/3;
            testCase.verifyEqual(actSolution,expSolution,'Abstol',1e-10);
        end

        %----------
        function testMonomialsP4(testCase)
            f = @(x) 1 + x + x.^2 + x.^3 + x.^4;
            actSolution = GaussQuadrature(f,4);
            expSolution = 46/15;
            testCase.verifyEqual(actSolution,expSolution,'Abstol',1e-10);
        end
    
        %----------
        function testMonomialsP5(testCase)
            f = @(x) 1 + x + x.^2 + x.^3 + x.^4 + x.^5;
            actSolution = GaussQuadrature(f,5);
            expSolution = 46/15;
            testCase.verifyEqual(actSolution,expSolution,'Abstol',1e-10);
        end

        %----------
        function testMonomialsP7(testCase)
            f = @(x) 1 + x + x.^2 + x.^3 + x.^4 + x.^5 + x.^6 + x.^7;
            actSolution = GaussQuadrature(f,7);
            expSolution = 352/105;
            testCase.verifyEqual(actSolution,expSolution,'Abstol',1e-10);
        end
        
        %----------
        function testMonomialsP9(testCase)
            f = @(x) 1 + x + x.^2 + x.^3 + x.^4 + x.^5 + x.^6 + x.^7 + x.^8 + x.^9;
            actSolution = GaussQuadrature(f,9);
            expSolution = 1126/315;
            testCase.verifyEqual(actSolution,expSolution,'Abstol',1e-10);
        end
        
        %----------
        function testMonomialsP11(testCase)
            f = @(x) 1 + x + x.^2 + x.^3 + x.^4 + x.^5 + x.^6 + x.^7 + x.^8 + x.^9 + x.^10 + x.^11;
            actSolution = GaussQuadrature(f,11);
            expSolution = 13016/3465;
            testCase.verifyEqual(actSolution,expSolution,'Abstol',1e-10);
        end
        
        %----------
        function testMonomialsP13(testCase)
            f = @(x) 1 + x + x.^2 + x.^3 + x.^4 + x.^5 + x.^6 + x.^7 + x.^8 + x.^9 + x.^10 + x.^11 + x.^12 + x.^13;
            actSolution = GaussQuadrature(f,13);
            expSolution = 176138/45045;
            testCase.verifyEqual(actSolution,expSolution,'Abstol',1e-10);
        end
        
    end
    
end