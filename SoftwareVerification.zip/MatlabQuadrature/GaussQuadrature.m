function int = GaussQuadrature(func,p)
%% Gaussian Quadrature integration
%Arguments:
%func = function handle of function to be integrated
%p = order of function to be integrated.

[pts,wghts] = getquadpts(p);

%evaluate the function at xi, multiply by the weight, and sum up    
int = sum( func(pts).*wghts );

end