%testscript
clear all
close all

profile on

run(testGaussQuadrature);

profile off