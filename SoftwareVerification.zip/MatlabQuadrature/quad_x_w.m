function [ pts, weights ] = quad_x_w(order)
% Determines the points and weights for Gauss Quad on [-1,1] 
% Follows www.math.siu.edu/matlab/tutorial5.pdf

% integral of f(x)dx from a to b = 
% (b-a)/2 * sum( w_i * f((b-a)/2*x_i + (a+b)/2) )
% where range = [a,b]

% Form the matrix whose eigenvalues are roots of ortho polys
k = 1:order-1;
d = k./(2*k - 1).*sqrt((2*k - 1)./(2*k + 1));
fc = 2;
J = diag(d,-1) + diag(d,1);
[u,v] = eig(J);
pts = sort(diag(v));
weights = (fc*u(1,:).^2)';
end

